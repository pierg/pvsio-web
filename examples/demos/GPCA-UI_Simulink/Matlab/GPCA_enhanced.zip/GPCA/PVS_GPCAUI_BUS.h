#ifndef PVS_GPCAUI_BUS_H
#define PVS_GPCAUI_BUS_H

struct PVS_GPCAUI_BUS {
    int    event;
    double programmedVTBI;
    double programmedDoseRate;
};

#endif